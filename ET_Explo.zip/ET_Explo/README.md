Slides de présentation sur les arbres de décision.

Présentation réalisée lors de l'école thématique Explo-SHS
